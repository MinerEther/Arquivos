#NsCpuCNMiner64 -o stratum+tcp://monerohash.com:3333 -u YOUR_WALLET_KEY_HERE -p x -t 4
import subprocess

p = subprocess.Popen(['NsCpuCNMiner32.exe', '-o', 'stratum+tcp://monerohash.com:3333', '-u', 'YOUR_WALLET_KEY_HERE', '-p', 'x', '-t', '4'], stdin=subprocess.PIPE)

p.wait()




